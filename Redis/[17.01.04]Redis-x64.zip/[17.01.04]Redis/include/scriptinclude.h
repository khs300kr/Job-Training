#pragma once



#include <iostream>
#include <tchar.h>
#include <windows.h>
#include <algorithm>
#include <functional>
#include <vector>

#pragma
extern "C" 
{
#include "include/lua.h"
#include "include/lualib.h"
#include "include/lauxlib.h"
#include "include/luajit.h"
}

//using namespace std;
